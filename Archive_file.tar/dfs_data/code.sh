#!/bin/bash
touch Data_Day_{1..100}

